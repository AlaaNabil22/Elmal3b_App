package com.alaa.elmal3b.Model;

public interface Listner {


    void getNewsListner (boolean status , ApiResponse apiResponse);
}
