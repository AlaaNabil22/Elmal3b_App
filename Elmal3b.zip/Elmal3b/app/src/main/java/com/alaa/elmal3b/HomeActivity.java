package com.alaa.elmal3b;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.alaa.elmal3b.Model.ApiResponse;
import com.alaa.elmal3b.Model.Listner;
import com.alaa.elmal3b.Retrofit.ApiCalling;

public class HomeActivity extends AppCompatActivity implements Listner {
    ApiCalling apiCalling;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        apiCalling = new ApiCalling(this);
        apiCalling.getNewsListner(this);
    }

    @Override
    public void getNewsListner(boolean status, ApiResponse apiResponse) {

    }
}
