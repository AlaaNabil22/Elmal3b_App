package com.alaa.elmal3b.Adapters;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.ItemHolder> {


}
